import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { UserProfile, ChatThread, Message, MembershipTier } from '../types';
import { getSpiritualInsight } from '../services/geminiService';

interface ChatDetailProps {
  user: UserProfile;
}

const ChatDetail: React.FC<ChatDetailProps> = ({ user }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [thread, setThread] = useState<ChatThread | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem(`threads_${user.email}`);
    if (saved) {
      const threads = JSON.parse(saved);
      const found = threads.find((t: ChatThread) => t.id === id);
      if (found) {
        setThread(found);
      } else {
        navigate('/');
      }
    }
    scrollToBottom();
  }, [id, user.email, navigate]);

  const scrollToBottom = () => {
    setTimeout(() => {
      scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !thread) return;

    const newMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      sender: 'user',
      text: input,
      timestamp: new Date(),
    };

    const updatedThread = {
      ...thread,
      messages: [...thread.messages, newMessage],
      status: thread.status === 'RESOLVED' ? 'ACTIVE' : thread.status,
    };

    setThread(updatedThread);
    setInput('');
    saveThread(updatedThread);
    scrollToBottom();

    // Simulating Elder response for the UI Demo
    if (user.tier !== MembershipTier.BASIC || thread.status === 'ACTIVE') {
      setLoading(true);
      try {
        const insight = await getSpiritualInsight(input, thread.messages.map(m => m.text).join('\n'));
        
        const elderResponse: Message = {
          id: Math.random().toString(36).substr(2, 9),
          sender: 'admin',
          text: insight,
          timestamp: new Date(),
        };

        const finalizedThread = {
          ...updatedThread,
          messages: [...updatedThread.messages, elderResponse],
        };
        
        setThread(finalizedThread);
        saveThread(finalizedThread);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
        scrollToBottom();
      }
    }
  };

  const saveThread = (t: ChatThread) => {
    const saved = localStorage.getItem(`threads_${user.email}`);
    if (saved) {
      const threads = JSON.parse(saved);
      const updatedThreads = threads.map((th: ChatThread) => th.id === t.id ? t : th);
      localStorage.setItem(`threads_${user.email}`, JSON.stringify(updatedThreads));
    }
  };

  if (!thread) return <div className="p-20 text-center">Gathering spirits...</div>;

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[80vh] bg-white rounded-3xl border border-stone-200 shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-stone-200 rounded-full">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
          </button>
          <div>
            <h2 className="font-cinzel text-lg font-bold text-emerald-900">{thread.title}</h2>
            <p className="text-xs text-stone-500 uppercase tracking-widest">{thread.category.replace('_', ' ')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
           <span className={`text-[10px] font-bold px-3 py-1 rounded-full border ${
             thread.status === 'ADMIN_DELAY' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
           }`}>
             {thread.status.replace('_', ' ')}
           </span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-grow overflow-y-auto p-6 space-y-6 bg-stone-50/30">
        {thread.messages.map((msg, idx) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl p-4 shadow-sm ${
              msg.sender === 'user' 
              ? 'bg-emerald-800 text-stone-50 rounded-tr-none' 
              : msg.sender === 'system' 
              ? 'bg-amber-50 text-amber-800 border border-amber-200 text-center mx-auto italic' 
              : 'bg-white text-stone-800 border border-stone-100 rounded-tl-none font-lora'
            }`}>
              {msg.sender === 'admin' && <p className="text-[10px] font-bold text-emerald-700 uppercase mb-1">Elders of Rumi Lodge</p>}
              <p className="text-sm leading-relaxed">{msg.text}</p>
              {msg.translatedText && (
                <div className="mt-3 pt-3 border-t border-emerald-700/30 text-xs italic opacity-80">
                  <p className="font-bold mb-1">Official Site Translation:</p>
                  {msg.translatedText}
                </div>
              )}
              <p className="text-[10px] mt-2 opacity-50 text-right">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
             <div className="bg-white border border-stone-100 rounded-2xl p-4 shadow-sm italic text-stone-400 text-xs flex items-center gap-2">
                <div className="flex gap-1">
                   <div className="w-1 h-1 bg-stone-400 rounded-full animate-bounce"></div>
                   <div className="w-1 h-1 bg-stone-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                   <div className="w-1 h-1 bg-stone-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
                Elders are reflecting...
             </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="p-6 border-t border-stone-100 bg-white">
        {thread.status === 'ADMIN_DELAY' && user.tier === MembershipTier.BASIC ? (
          <div className="text-center p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-800 text-xs">
            <p className="font-bold mb-1">Admin Visibility Delay (Basic Tier)</p>
            {/* Fix: Added missing Link component for correct internal navigation */}
            <p>Our elders will receive this message stream 12 hours after your initial inquiry. <Link to="/membership" className="underline">Upgrade for instant access.</Link></p>
          </div>
        ) : (
          <form onSubmit={handleSendMessage} className="flex gap-3">
            <input 
              type="text"
              placeholder="Continue the spiritual dialogue..."
              className="flex-grow p-4 bg-stone-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button 
              type="submit"
              disabled={!input.trim()}
              className="bg-emerald-800 text-white p-4 rounded-2xl hover:bg-emerald-900 transition-colors disabled:bg-stone-200"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ChatDetail;