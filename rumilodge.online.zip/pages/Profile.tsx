
import React, { useState } from 'react';
import { UserProfile, MembershipTier } from '../types';

interface ProfileProps {
  user: UserProfile;
  setUser: (u: UserProfile) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, setUser }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ ...user });

  const handleSave = () => {
    setUser(editData);
    localStorage.setItem('rumi_user', JSON.stringify(editData));
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <div className="bg-white rounded-3xl border border-stone-200 shadow-2xl overflow-hidden">
        <div className="h-32 bg-emerald-900"></div>
        <div className="px-8 pb-8">
          <div className="relative flex justify-between items-end -mt-12 mb-6">
            <div className="w-24 h-24 bg-white p-1 rounded-full border-4 border-white shadow-xl">
               <div className="w-full h-full bg-emerald-50 rounded-full flex items-center justify-center text-3xl font-cinzel text-emerald-800 font-bold overflow-hidden">
                  {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : user.name[0]}
               </div>
            </div>
            <button 
              onClick={() => isEditing ? handleSave() : setIsEditing(true)}
              className="bg-emerald-800 text-white px-6 py-2 rounded-full text-sm font-bold shadow-md hover:bg-emerald-700 transition-all"
            >
              {isEditing ? 'Save Journey' : 'Update Profile'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              {isEditing ? (
                <>
                  <input 
                    className="text-2xl font-cinzel font-bold block w-full border-b focus:outline-none"
                    value={editData.name}
                    onChange={(e) => setEditData({...editData, name: e.target.value})}
                  />
                  <input 
                    className="text-stone-500 block w-full border-b focus:outline-none"
                    value={editData.location}
                    placeholder="Location"
                    onChange={(e) => setEditData({...editData, location: e.target.value})}
                  />
                  <textarea 
                    className="text-stone-600 block w-full border border-stone-100 p-2 rounded focus:outline-none italic font-lora"
                    value={editData.bio}
                    rows={4}
                    onChange={(e) => setEditData({...editData, bio: e.target.value})}
                  />
                </>
              ) : (
                <>
                  <h1 className="text-3xl font-cinzel font-bold text-stone-800">{user.name}</h1>
                  <p className="text-stone-500 flex items-center gap-1">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    {user.location || 'Spiritual Nomad'}
                  </p>
                  <p className="text-stone-600 font-lora italic leading-relaxed">"{user.bio}"</p>
                </>
              )}
            </div>

            <div className="space-y-6">
              <div className="bg-stone-50 p-6 rounded-2xl border border-stone-100">
                <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-3">Membership Status</h3>
                <div className="flex items-center justify-between">
                  <span className={`text-sm font-bold px-3 py-1 rounded-full border ${
                    user.tier === MembershipTier.TRAINEE ? 'bg-amber-100 border-amber-300 text-amber-700' : 'bg-emerald-100 border-emerald-300 text-emerald-700'
                  }`}>
                    {user.tier}
                  </span>
                  <Link to="/membership" className="text-xs text-emerald-800 hover:underline font-bold">Manage Plan</Link>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-stone-50 p-4 rounded-2xl text-center">
                  <p className="text-2xl font-bold text-emerald-800">12</p>
                  <p className="text-[10px] text-stone-500 font-bold uppercase">Journal Entries</p>
                </div>
                <div className="bg-stone-50 p-4 rounded-2xl text-center">
                  <p className="text-2xl font-bold text-emerald-800">4</p>
                  <p className="text-[10px] text-stone-500 font-bold uppercase">Elder Guidance</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {user.tier === MembershipTier.TRAINEE && (
        <div className="bg-emerald-50 rounded-3xl p-8 border border-emerald-100">
           <h2 className="font-cinzel text-xl font-bold text-emerald-900 mb-6">Your Mystic Curriculum</h2>
           <div className="space-y-4">
              <div className="flex justify-between text-sm font-semibold">
                 <span>Preparation & Off-site study</span>
                 <span>50%</span>
              </div>
              <div className="w-full bg-emerald-200 rounded-full h-3">
                 <div className="bg-emerald-700 h-3 rounded-full" style={{ width: '50%' }}></div>
              </div>
              <p className="text-xs text-stone-500 italic mt-4">Remaining milestones: 3 months of off-site preparation followed by 3 months residency at the Konya Monastry.</p>
           </div>
        </div>
      )}
    </div>
  );
};

// Helper Link import
import { Link } from 'react-router-dom';

export default Profile;
