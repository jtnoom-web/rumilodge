
import React from 'react';
import { UserProfile, MembershipTier } from '../types';

interface MembershipProps {
  user: UserProfile;
  onUpgrade: (tier: MembershipTier) => void;
}

const Membership: React.FC<MembershipProps> = ({ user, onUpgrade }) => {
  const tiers = [
    {
      id: MembershipTier.BASIC,
      name: 'Basic Seeker',
      price: 'Free',
      features: [
        'Response within 24 hours',
        '12-hour delay before admins see inquiry',
        'Spiritual Journaling',
        'Language Auto-translation',
      ],
      color: 'bg-stone-100',
      text: 'text-stone-800'
    },
    {
      id: MembershipTier.ENLIGHTENED,
      name: 'Enlightened',
      price: '$10/mo',
      features: [
        'Instant visibility to admins',
        'Priority Response',
        'Video/Image Analysis',
        'Ad-free experience',
      ],
      color: 'bg-emerald-50 border-emerald-200',
      text: 'text-emerald-900',
      recommended: true
    },
    {
      id: MembershipTier.SAGE,
      name: 'Sage Circle',
      price: '$50/mo',
      features: [
        'Everything in Enlightened',
        '24/7 Phone & WhatsApp Help Line',
        'Direct connection to senior masters',
        'Private group sessions',
      ],
      color: 'bg-amber-50 border-amber-200',
      text: 'text-amber-900'
    },
    {
      id: MembershipTier.TRAINEE,
      name: 'Mystic Student',
      price: '$100/mo',
      features: [
        'Full 1-Year Spiritual Transformation',
        '6 Months Structured Off-Site Training',
        '3 Months Monastery Residency Included',
        'Direct Monk Supervision',
        'Eligibility to teach local chapters',
      ],
      color: 'bg-emerald-900',
      text: 'text-emerald-50'
    }
  ];

  return (
    <div className="space-y-12 animate-fadeIn">
      <div className="text-center max-w-2xl mx-auto">
        <h1 className="font-cinzel text-4xl font-bold text-emerald-900 mb-4">Ascend the Tiers</h1>
        <p className="text-stone-600 font-lora italic">Support the Lodge and accelerate your spiritual transformation.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {tiers.map(tier => (
          <div 
            key={tier.id}
            className={`flex flex-col p-8 rounded-3xl border shadow-xl relative transition-transform hover:scale-105 ${tier.color} ${tier.text}`}
          >
            {tier.recommended && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 text-emerald-950 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-tighter">Recommended</span>
            )}
            <div className="mb-6">
              <h3 className="font-cinzel text-xl font-bold">{tier.name}</h3>
              <p className="text-3xl font-bold mt-2">{tier.price}</p>
            </div>
            <ul className="space-y-4 mb-8 flex-grow">
              {tier.features.map((f, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <svg className="w-5 h-5 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg>
                  {f}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => onUpgrade(tier.id)}
              disabled={user.tier === tier.id}
              className={`w-full py-3 rounded-xl font-bold transition-all shadow-md ${
                user.tier === tier.id 
                ? 'bg-stone-300 text-stone-500 cursor-not-allowed' 
                : tier.id === MembershipTier.TRAINEE ? 'bg-amber-500 text-emerald-950 hover:bg-amber-400' : 'bg-emerald-800 text-white hover:bg-emerald-700'
              }`}
            >
              {user.tier === tier.id ? 'Current Path' : 'Select Path'}
            </button>
          </div>
        ))}
      </div>

      <div className="bg-stone-50 border border-stone-200 p-8 rounded-3xl mt-12">
        <h2 className="font-cinzel text-2xl font-bold text-stone-800 mb-4 text-center">The Trainee Path Explained</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center text-stone-600 font-lora">
           <div>
              <div className="w-12 h-12 bg-emerald-800 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold">1</div>
              <h4 className="font-bold text-stone-800 mb-2">Preparation (6 Months)</h4>
              <p className="text-sm">Structured meditations and studies performed at your own home under digital guidance.</p>
           </div>
           <div>
              <div className="w-12 h-12 bg-emerald-800 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold">2</div>
              <h4 className="font-bold text-stone-800 mb-2">Monastery Visit (3 Months)</h4>
              <p className="text-sm">Live among the Monks and Sufi masters. Experience direct transmission of spiritual energy.</p>
           </div>
           <div>
              <div className="w-12 h-12 bg-emerald-800 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold">3</div>
              <h4 className="font-bold text-stone-800 mb-2">Empowerment</h4>
              <p className="text-sm">Upon graduation, you are authorized to establish and teach in your own local Rumi Lodge chapter.</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Membership;
