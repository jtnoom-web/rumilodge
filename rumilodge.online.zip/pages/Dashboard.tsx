
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { UserProfile, ChatThread, MembershipTier } from '../types';

interface DashboardProps {
  user: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [threads, setThreads] = useState<ChatThread[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(`threads_${user.email}`);
    if (saved) {
      setThreads(JSON.parse(saved));
    } else {
      // Mock some initial data if empty
      const initial: ChatThread[] = [
        {
          id: 'initial-1',
          title: 'Welcome to Rumi Lodge',
          category: 'MYSTICAL_TRAINING',
          status: 'RESOLVED',
          createdAt: new Date(),
          tierAtTime: MembershipTier.BASIC,
          messages: [
            { 
              id: 'm1', 
              sender: 'admin', 
              text: 'Welcome, seeker. This is your personal journal and spiritual portal. How may we assist you today?', 
              timestamp: new Date() 
            }
          ]
        }
      ];
      setThreads(initial);
      localStorage.setItem(`threads_${user.email}`, JSON.stringify(initial));
    }
  }, [user.email]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'ADMIN_DELAY': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'ACTIVE': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'RESOLVED': return 'bg-stone-100 text-stone-600 border-stone-200';
      default: return 'bg-stone-100 text-stone-600';
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-cinzel text-3xl font-bold text-emerald-900">Salutations, {user.name}</h1>
          <p className="text-stone-500 italic font-lora">Reflect on your spiritual evolution below.</p>
        </div>
        <Link 
          to="/new" 
          className="bg-emerald-800 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:bg-emerald-700 transition-all flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
          Ask the Elders
        </Link>
      </header>

      {user.tier === MembershipTier.TRAINEE && (
        <section className="bg-emerald-950 text-emerald-100 p-6 rounded-2xl shadow-xl border-l-8 border-amber-500">
           <div className="flex items-center justify-between mb-4">
              <h2 className="font-cinzel text-xl font-bold">Mystic Path Progress</h2>
              <span className="text-xs bg-amber-500 text-emerald-950 px-2 py-0.5 rounded-full font-bold uppercase">Trainee Phase 1</span>
           </div>
           <div className="w-full bg-emerald-900 rounded-full h-2.5 mb-2">
              <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: '45%' }}></div>
           </div>
           <div className="flex justify-between text-xs font-semibold">
              <span>6 Months Off-Site (3/6 complete)</span>
              <span>Monastery Visit Pending</span>
           </div>
        </section>
      )}

      <div className="grid grid-cols-1 gap-6">
        <h2 className="font-cinzel text-2xl border-b pb-2 text-stone-700">Recent Conversations</h2>
        
        {threads.length === 0 ? (
          <div className="py-20 text-center text-stone-400 border-2 border-dashed border-stone-200 rounded-3xl">
            <p className="italic">Silence is the language of God, all else is poor translation.</p>
            <p className="text-sm mt-2">Submit your first inquiry to begin.</p>
          </div>
        ) : (
          threads.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(thread => (
            <Link 
              key={thread.id} 
              to={`/chat/${thread.id}`}
              className="bg-white p-6 rounded-2xl border border-stone-200 hover:border-emerald-300 hover:shadow-xl transition-all group"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded border ${getStatusColor(thread.status)}`}>
                    {thread.status.replace('_', ' ')}
                  </span>
                  <h3 className="text-xl font-cinzel font-bold mt-2 group-hover:text-emerald-800 transition-colors">{thread.title}</h3>
                </div>
                <div className="text-right text-xs text-stone-400">
                  <p>{new Date(thread.createdAt).toLocaleDateString()}</p>
                  <p className="font-bold text-emerald-600/50">{thread.category.replace('_', ' ')}</p>
                </div>
              </div>
              <p className="text-stone-600 line-clamp-2 italic font-lora">
                {thread.messages[thread.messages.length - 1]?.text}
              </p>
              
              {thread.status === 'ADMIN_DELAY' && thread.tierAtTime === MembershipTier.BASIC && (
                <div className="mt-4 flex items-center gap-2 text-amber-600 text-xs font-semibold bg-amber-50 p-2 rounded-lg">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                  Basic Tier: Questions appear to experts after 12 hours. 
                  <Link to="/membership" className="underline font-bold ml-1">Upgrade for Instant access</Link>
                </div>
              )}
            </Link>
          ))
        )}
      </div>
    </div>
  );
};

export default Dashboard;
