
import React, { useState } from 'react';
import { UserProfile, MembershipTier } from '../types';

interface LoginProps {
  onLogin: (user: UserProfile) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate auth
    onLogin({
      name: formData.name || 'Seeker',
      email: formData.email || 'seeker@mystic.com',
      tier: MembershipTier.BASIC,
      bio: "Walking the path of the heart.",
    });
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-8 bg-white border border-stone-200 shadow-2xl rounded-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-2 bg-emerald-800"></div>
      
      <div className="text-center mb-8">
        <h1 className="font-cinzel text-3xl font-bold text-stone-800">Rumi Lodge</h1>
        <p className="text-stone-500 font-lora italic">Portal of the Heart</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {isRegister && (
          <div>
            <label className="block text-sm font-semibold mb-1">Full Name</label>
            <input 
              required
              type="text" 
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" 
              placeholder="Jalaluddin Rumi"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
        )}
        <div>
          <label className="block text-sm font-semibold mb-1">Email Address</label>
          <input 
            required
            type="email" 
            className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" 
            placeholder="email@example.com"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
          />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1">Passphrase</label>
          <input 
            required
            type="password" 
            className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" 
            placeholder="••••••••"
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
          />
        </div>

        <button 
          type="submit" 
          className="w-full bg-emerald-800 text-white font-bold py-3 rounded-lg hover:bg-emerald-900 transition-colors shadow-lg"
        >
          {isRegister ? 'Begin Your Journey' : 'Enter the Lodge'}
        </button>
      </form>

      <div className="mt-6 text-center text-sm">
        <button 
          onClick={() => setIsRegister(!isRegister)} 
          className="text-emerald-700 font-bold hover:underline"
        >
          {isRegister ? 'Already a member? Enter here' : 'New seeker? Create a portal'}
        </button>
      </div>
    </div>
  );
};

export default Login;
