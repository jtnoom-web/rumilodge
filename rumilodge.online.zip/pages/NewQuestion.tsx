
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserProfile, QuestionCategory, MembershipTier, ChatThread } from '../types';
import { detectLanguage, translateText } from '../services/geminiService';

interface NewQuestionProps {
  user: UserProfile;
}

const NewQuestion: React.FC<NewQuestionProps> = ({ user }) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    category: 'DREAM' as QuestionCategory,
    title: '',
    description: '',
    caseHistory: '',
    media: null as File | null,
  });

  const categories = [
    { value: 'DREAM', label: 'Dream Interpretation' },
    { value: 'SPIRITUAL_EXPERIENCE', label: 'Spiritual Experience' },
    { value: 'SPIRITUAL_SYNDROME', label: 'Spiritual Syndrome' },
    { value: 'MYSTICAL_TRAINING', label: 'Mystical Training' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // 1. Detect language
      const lang = await detectLanguage(formData.description);
      let officialText = formData.description;
      
      // 2. If not Eng/Urdu, translate (Requirement)
      const isOfficial = lang.includes('english') || lang.includes('urdu');
      if (!isOfficial) {
        officialText = await translateText(formData.description, 'en');
      }

      // 3. Create the thread
      const newThread: ChatThread = {
        id: Math.random().toString(36).substr(2, 9),
        title: formData.title,
        category: formData.category,
        status: user.tier === MembershipTier.BASIC ? 'ADMIN_DELAY' : 'PENDING',
        createdAt: new Date(),
        tierAtTime: user.tier,
        messages: [
          {
            id: 'm1',
            sender: 'user',
            text: formData.description,
            translatedText: !isOfficial ? officialText : undefined,
            timestamp: new Date(),
          },
          {
            id: 'm-sys',
            sender: 'system',
            text: `Seeker, your inquiry has been logged. ${user.tier === MembershipTier.BASIC ? 'As a Basic Tier member, our elders will receive this in 12 hours.' : 'Our elders are reviewing your message now.'} Peace be with you.`,
            timestamp: new Date(),
          }
        ]
      };

      // Save
      const saved = localStorage.getItem(`threads_${user.email}`);
      const threads = saved ? JSON.parse(saved) : [];
      localStorage.setItem(`threads_${user.email}`, JSON.stringify([...threads, newThread]));
      
      navigate(`/chat/${newThread.id}`);
    } catch (err) {
      console.error(err);
      alert("Something went wrong with the spiritual transmission. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fadeIn">
      <div className="text-center">
        <h1 className="font-cinzel text-3xl font-bold text-emerald-900">Seek Guidance</h1>
        <p className="text-stone-500 font-lora italic">Share your heart, your visions, and your struggles.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl border border-stone-200 shadow-xl space-y-6">
        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Category of Inquiry</label>
          <div className="grid grid-cols-2 gap-3">
            {categories.map(cat => (
              <button
                key={cat.value}
                type="button"
                onClick={() => setFormData({...formData, category: cat.value as QuestionCategory})}
                className={`p-3 text-sm font-semibold rounded-xl border transition-all ${
                  formData.category === cat.value 
                  ? 'bg-emerald-800 text-white border-emerald-800' 
                  : 'bg-stone-50 text-stone-600 border-stone-200 hover:border-emerald-400'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Topic Heading</label>
          <input 
            required
            type="text"
            className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            placeholder="e.g. Vision of a white bird in the garden"
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Detailed Description</label>
          <textarea 
            required
            rows={5}
            className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            placeholder="Describe your dream or experience in detail..."
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Case History & Personal Context</label>
          <p className="text-xs text-stone-400 mb-2 italic">More personal details allow our experts to provide a more fine-tuned spiritual response.</p>
          <textarea 
            rows={3}
            className="w-full p-4 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-lora"
            placeholder="Your spiritual background, emotional state, recent life changes..."
            value={formData.caseHistory}
            onChange={(e) => setFormData({...formData, caseHistory: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Upload Visual Aids (Pictures/Videos)</label>
          <input 
            type="file" 
            accept="image/*,video/*"
            className="w-full text-sm text-stone-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100"
            onChange={(e) => setFormData({...formData, media: e.target.files ? e.target.files[0] : null})}
          />
        </div>

        <button 
          disabled={loading}
          type="submit" 
          className="w-full bg-emerald-800 text-white font-bold py-4 rounded-2xl hover:bg-emerald-900 transition-all shadow-xl disabled:bg-stone-300 flex items-center justify-center gap-3"
        >
          {loading ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
              Transmitting inquiry...
            </>
          ) : (
            'Submit to the Elders'
          )}
        </button>
      </form>
    </div>
  );
};

export default NewQuestion;
