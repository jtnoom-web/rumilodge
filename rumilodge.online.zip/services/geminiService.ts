import { GoogleGenAI, Type } from "@google/genai";

// Fix: Use mandatory named parameter and direct process.env.API_KEY reference for initialization
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const translateText = async (text: string, targetLang: 'en' | 'ur' | 'auto'): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Translate the following text to ${targetLang === 'auto' ? 'English' : targetLang === 'ur' ? 'Urdu' : 'English'}. If it's already in that language, return as is. Only return the translated text:\n\n${text}`,
  });
  return response.text?.trim() || text;
};

export const detectLanguage = async (text: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Detect the language of this text. Return only the language name (e.g., "Urdu", "English", "French"):\n\n${text}`,
  });
  return response.text?.trim().toLowerCase() || 'unknown';
};

export const getSpiritualInsight = async (prompt: string, context: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `You are a high-level spiritual consultant at Rumi Lodge. 
    Context: ${context}
    The seeker asks: ${prompt}
    
    Provide a deeply thoughtful, compassionate, and mystical response. Focus on Sufi wisdom, psychological depth, and mystical interpretation. Keep it professional yet soulful.`,
  });
  return response.text || "May peace be upon you. We are reflecting on your journey.";
};